Here we would put some training or test data depending on the phase. This will probably be something different in each phase:

* Phase 1: development. We would make "public data" available for download for practice purposes.

* Phase 2: feed-back. We would make validation "input data" available to the code submission of the participants, for immediate on-line feed-back.

* Phase 1: final test. We would make final test "input data" available to the code submission of the participants, for final ranking.