#!/usr/bin/env python
import json
import os.path
import sys

# as per the metadata file, input and output directories are the arguments
[_, input_dir, output_dir] = sys.argv

truth_values = {}

# unzipped submission data is always in the 'res' subdirectory
# https://github.com/codalab/codalab-competitions/wiki/User_Building-a-Scoring-Program-for-a-Competition#directory-structure-for-submissions
submission_path = os.path.join(input_dir, 'res', 'result.json')
if not os.path.exists(submission_path):
    sys.exit('Could not find submission file {0}'.format(submission_path))
with open(submission_path) as submission_file:
	submission = json.load(submission_file)

# unzipped reference data is always in the 'ref' subdirectory
with open(os.path.join(input_dir, 'ref', 'subtaskA.json')) as truth_file:
    truth_values = json.load(truth_file)

# the scores for the leaderboard must be in a file named "scores.txt"
with open(os.path.join(output_dir, 'scores.txt'), 'w') as output_file:

	observed = 0
	correct = 0

	for reference_id in truth_values.keys():
		if reference_id in submission.keys():
			observed += 1
			if submission[reference_id] == truth_values[reference_id]:
				correct += 1
			print('found entry', reference_id)

		else:
			print('unmatched entry:', reference_id, '-- no reference value for this document')


	score = float(correct) / observed

	output_file.write("score:{0}\n".format(score))
